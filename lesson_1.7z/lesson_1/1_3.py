usr_inp = input('Enter your number: ')

usr_inp_2 = usr_inp + usr_inp

usr_inp_3 = usr_inp + usr_inp_2

result = int(usr_inp) + int(usr_inp_2) + int(usr_inp_3)

print(result)
