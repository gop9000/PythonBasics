empty_line = ''
print('This is a test to find out your age and name.')

print(empty_line)

age = input('Enter your age: ')

print(empty_line)

name = input('Enter your name: ')

print(empty_line)

print(f'Your name is {name} and your age is {age}.')

print(empty_line)

print('You see, we know your name and age!')

print(empty_line)
