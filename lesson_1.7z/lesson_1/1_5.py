inc = int(input('Enter your income: '))

print('')

exp = int(input('Enter your expenses: '))

print('')

res = inc - exp

if res > 0:

	print('Company works with profit!')

else:

	print('Company works with losses!')

